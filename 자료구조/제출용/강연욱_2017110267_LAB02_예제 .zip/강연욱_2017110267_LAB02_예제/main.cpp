#include "Application.h"

using namespace std;

int main(){
    
    Application app;
    app.Run();
    
    return 0;
}

/*
 PPT파일의 '예제: SortedList ADT'를 참고하여 메소드를 설정하였습니다.
 
 */
