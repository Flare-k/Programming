#include "Application.h"

using namespace std;

int main(){
    
    Application app;
    app.Run();
    
    return 0;
}
/*
 Application class의 객체를 생성해주고
 메소드 Run()을 사용하여 SortedList, ItemType class의 내용들을 구현할 수 있게끔 한다.
 */
