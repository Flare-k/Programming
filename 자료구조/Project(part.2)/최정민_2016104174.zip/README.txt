﻿사용설명서 - 2016104174 컴퓨터공학과 최정민

-프로그램 설명
 - 음원관리 시스템의 가장 기초적인 기능(자료구조 수업시간에 진행한내용) + 음원재생+음원차트기능을 추가

  -프로그램 작동법

  프로그램을 시작하게 되면 가장 기본메뉴가 뜨면서 원하는 카테고리에 알맞은 정수를 입력한다

  1) SongList선택 한경우 (정수 1을 입력)

    SongList에 관한 메뉴들이 뜨면서 실행하기 원하는 기능에 맞는 정수를 입력한다.
 
     i) Add Song을 선택(정수 1를 입력) : song list에 음원을 추가한다(국가, 곡이름, 작곡가, 가수이름, 장르, id 입력)
         ㄴ같은 id의 음원이 존재시 음원 추가 실패
     ii) Delete Song을 선택(정수 2를 입력) : 삭제하고자 하는 음원을 id를 입력한다
     iii) Replace Song을 선택(정수 3를 입력) : 대체하고자 하는 음원과 같은 id의 음원을 입력한다
     iv) Display all song을 선택(정수 4를 입력) : song list에 있는 음원들의 정보를 출력한다
     v) Make song list Empty(정수 5를 입력) : song list를 초기화 시킨다.
     0) Quit(정수 0를 입력) : SongList 메뉴에서 나간다

  2) MY PLAYLIST선택 한경우 (정수 2을 입력)

    MY PLAYLIST에 관한 메뉴들이 뜨면서 실행하기 원하는 기능에 맞는 정수를 입력한다.

     i) Add to playList을 선택(정수 1를 입력) : 곡제목을 입력하여 playlist에 음악을 추가한다
         ㄴSonglist에 음원이 없으면 실패
     ii) Delete to playList을 선택(정수 2를 입력) : play list에서 삭제하고자 하는 음원의 제목을 입력한다
         ㄴplaylist에 음원이 없으면 실패
     iii) Play to Music을 선택(정수 3를 입력) : 재생하고자하는 음원의 제목을 입력하여 음원재생
         ㄴplasylist에 음원이 없거나 파일에 음원파일(wav파일)이 없으면 실패
     iv) Display ALL MUSIC을 선택(정수 4를 입력) : play list에 있는 곡들의 정보를 출력한다
     0) Quit(정수 0를 입력) : MY PLAYList 메뉴에서 나간다

  3) TOP 5 선택 한경우 (정수 3을 입력)

    SONG LIST중에서 검색빈도순으로 음원이 뜬다 (만약 음원 개수가 부족할경우 공석으로 둔다)

  4) Search the music선택 한경우 (정수 4을 입력)

    Search the music에 관한 메뉴들이 뜨면서 실행하기 원하는 기능에 맞는 정수를 입력한다.

     i) General Search을 선택(정수 1를 입력) : 검색어를 입력하여 해당검색와 일치하거나 비슷한 경우를 출력(제목, 가수 장르)
     ii) Search with id을 선택(정수 2를 입력) : id로 음원을 검색한다.
     0) Quit(정수 0를 입력) : Search the music 메뉴에서 나간다

  5) Data Read/Save선택 한경우 (정수 5을 입력)

    Data 저장과 불러오기 에 관한 메뉴들이 뜨면서 실행하기 원하는 기능에 맞는 정수를 입력한다.

     i) Save data to File을 선택(정수 1를 입력) : 세이브할 파일의 이름을 지정한다.(파일생성)
     ii) Read data firn file을 선택(정수 2를 입력) : 불러올 세이브파일의 이름을 입력한
         ㄴ해당 세이브파일이 없거나 옳은 형식이 아니면 실패
     0) Quit(정수 0를 입력) : Data Read/Save 메뉴에서 나간다

  0) Quit선택 한경우 (정수 0을 입력)

    프로그램 종료
