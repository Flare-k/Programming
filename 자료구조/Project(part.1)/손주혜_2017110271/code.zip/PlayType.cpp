#include "PlayType.h"

PlayType::PlayType(){}

PlayType::~PlayType(){}


void PlayType::DisplayPlaylistOnScreen() 
{
	DisplayName();
	DisplayProducer();
	DisplaySinger();
	DisplayId();

}

