#include <string>
#include <iostream>
using namespace std;

class SingerType {
public:
	SingerType() {
		s_id = 0;
		s_name = "";
		s_age = 0;
		s_gender = "";
	};
	SingerType(int id) {
		s_id = id;
		s_name = "";
		s_age = 0;
		s_gender = "";
	};

	~SingerType() {};

private:
	int s_id;
	string s_name;
	int s_age;
	string s_gender;

};