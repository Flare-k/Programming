#include "SingerItem.h"

// Set music Id from keyboard.
void SingerItem::SetNameFromKB()
{
	cout << "\tName : ";
	cin >> m_Name;
	SetName(m_Name);
}

// Set music NumPlay from keyboard.
void SingerItem::SetAgeFromKB()
{
	cout << "\tAge : ";
	cin >> m_Age;
	SetAge(m_Age);
}

// Set music InTime from keyboard.
void SingerItem::SetGenderFromKB()
{
	cout << "\tGender : ";
	cin >> m_Gender;
	SetGender(m_Gender);
}

// Set music record from keyboard.
void SingerItem::SetRecordFromKB()
{
	SetNameFromKB();
	SetAgeFromKB();
	SetGenderFromKB();
}

// Compare two itemtypes.
bool SingerItem::operator==(const SingerItem &data)
{
	if (this->m_Name == data.m_Name)
		return true;
	return false;
}

// �� item�� ���� (deep copy)
void SingerItem::operator=(const SingerItem &data)
{
	this->m_Name = data.m_Name;		///< name
	this->m_Age = data.m_Age;		///< age
	this->m_Gender = data.m_Gender;		///< gender
	this->m_SongList = data.m_SongList;
}

// �� item�� ��
bool SingerItem::operator>(const SingerItem &data)
{
	if (this->m_Name > data.m_Name)
		return true;
	return false;
}