#pragma once

#include <iostream>
#include <string>

using namespace std;


/**
*	item information class.
*/
class SongItem
{
public:
	/**
	*	default constructor.
	*/
	SongItem()
	{
		m_Id = -1;
		m_Name = "";
	}

	/**
	*	destructor.
	*/
	~SongItem() {}

	/**
	*	@brief	Get name.
	*	@pre	name is set.
	*	@post	none.
	*	@returnname
	*/
	string GetName()
	{
		return m_Name;
	}

	/**
	*	@brief	Get id.
	*	@pre	id is set.
	*	@post	none.
	*	@return	id.
	*/
	int GetId()
	{
		return m_Id;
	}

	/**
	*	@brief	Set name.
	*	@pre	none.
	*	@post	name is set.
	*	@param	inname	name.
	*/
	void SetName(string inName)
	{
		m_Name = inName;
	}

	/**
	*	@brief	Set id.
	*	@pre	none.
	*	@post	id is set.
	*	@param	inid	id.
	*/
	void SetId(int inId)
	{
		m_Id = inId;
	}

	/**
	*	@brief	Set music record.
	*	@pre	none.
	*	@post	music record is set.
	*	@param	inId	id.
	*	@param	inname	name.
	*/
	void SetRecord(int inId, string inName)
	{
		SetId(inId);
		SetName(inName);
	}

	/**
	*	@brief	Display name on screen.
	*	@pre	name is set.
	*	@post	name is on screen.
	*/
	void DisplayNameOnScreen()
	{
		cout << "\tName   : " << m_Name << endl;
	}

	/**
	*	@brief	Display id on screen.
	*	@pre	id is set.
	*	@post	id is on screen.
	*/
	void DisplayIdOnScreen()
	{
		cout << "\tId : " << m_Id << endl;
	}

	/**
	*	@brief	Display a music record on screen.
	*	@pre	music record is set.
	*	@post	music record is on screen.
	*/
	void DisplayRecordOnScreen()
	{
		DisplayIdOnScreen();
		DisplayNameOnScreen();
	}

	/**
	*	@brief	Set name from keyboard.
	*	@pre	none.
	*	@post	name is set.
	*/
	void SetNameFromKB();

	/**
	*	@brief	Set id from keyboard.
	*	@pre	none.
	*	@post	id is set.
	*/
	void SetIdFromKB();

	/**
	*	@brief	Set music record from keyboard.
	*	@pre	none.
	*	@post	music record is set.
	*/
	void SetRecordFromKB();

	/**
	*	Compare two itemtypes.
	*	@brief	Compare two item types by item id.
	*	@pre	two item types should be initialized.
	*	@post	the target file is included the new item record.
	*	@param	data	target item for comparing.
	*	@return	return == is true if this.id == data.id then,
	*/
	bool operator==(const SongItem &data);
	void operator=(const SongItem &data);

protected:
	int m_Id;	///< id
	string m_Name; ///< name
};