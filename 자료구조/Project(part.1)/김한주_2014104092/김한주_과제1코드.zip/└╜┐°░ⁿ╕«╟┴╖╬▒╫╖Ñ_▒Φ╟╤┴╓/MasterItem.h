
#ifndef _ITEMTYPE_H
#define _ITEMTYPE_H

#include <iostream>
#include <fstream>
#include <string>

using namespace std;


/**
*	item information class.
*/
class MasterItem
{
public:
	/**
	*	default constructor.
	*/
	MasterItem()
	{
		int m_Type = -1;
		string m_Name = "";
		string m_Composer = "";
		string m_Singer = "";
		int m_Genre = -1;
		string m_Id = "";
	}

	/**
	*	destructor.
	*/
	~MasterItem() {}

	/**
	*	@brief	Get music type.
	*	@pre	music type is set.
	*	@post	none.
	*	@return	music type
	*/
	int GetType()
	{
		return m_Type;
	}

	/**
	*	@brief	Get music name.
	*	@pre	music name is set.
	*	@post	none.
	*	@return	music name.
	*/
	string GetName()
	{
		return m_Name;
	}

	/**
	*	@brief	Get music composer
	*	@pre	music composer is set.
	*	@post	none.
	*	@return	music composer.
	*/
	string GetComposer()
	{
		return m_Composer;
	}

	/**
	*	@brief	Get music singer
	*	@pre	music singer is set.
	*	@post	none.
	*	@return	music singer
	*/
	string GetSinger()
	{
		return m_Singer;
	}

	/**
	*	@brief	Get music genre
	*	@pre	music genre is set.
	*	@post	none.
	*	@return	music genre
	*/
	int GetGenre()
	{
		return m_Genre;
	}

	/**
	*	@brief	Get music id
	*	@pre	music id is set.
	*	@post	none.
	*	@return	music id
	*/
	string GetId()
	{
		return m_Id;
	}

	/**
	*	@brief	Set music type.
	*	@pre	none.
	*	@post	music type is set.
	*	@param	inType	music type.
	*/
	void SetType(int inType)
	{
		m_Type = inType;
	}

	/**
	*	@brief	Set music name.
	*	@pre	none.
	*	@post	music name is set.
	*	@param	inName	music name.
	*/
	void SetName(string inName)
	{
		m_Name = inName;
	}

	/**
	*	@brief	Set music composer.
	*	@pre	none.
	*	@post	music composer is set.
	*	@param	inComposer	music composer.
	*/
	void SetComposer(string inComposer)
	{
		m_Composer = inComposer;
	}

	/**
	*	@brief	Set music singer.
	*	@pre	none.
	*	@post	music singer is set.
	*	@param	inSinger	music singer.
	*/
	void SetSinger(string inSinger)
	{
		m_Singer = inSinger;
	}

	/**
	*	@brief	Set music genre.
	*	@pre	none.
	*	@post	music genre is set.
	*	@param	inGenre	music genre.
	*/
	void SetGenre(int inGenre)
	{
		m_Genre = inGenre;
	}

	/**
	*	@brief	Set music id.
	*	@pre	none.
	*	@post	music id is set.
	*	@param	inId	music id.
	*/
	void SetId(string inId)
	{
		m_Id = inId;
	}

	/**
	*	@brief	Set music record.
	*	@pre	none.
	*	@post	music record is set.
	*	@param	inType	music type.
	*	@param	inName	music name.
	*	@param	inComposer music composer
	*	@param	inSinger music singer
	*	@param	inGenre music genre
	*	@param	inId music id
	*/
	void SetRecord(int inType, string inName, string inComposer, string inSinger, int inGenre, string inId)
	{
		SetType(inType);
		SetName(inName);
		SetComposer(inComposer);
		SetSinger(inSinger);
		SetGenre(inGenre);
		SetId(inId);
	}

	/**
	*	@brief	Display music type on screen.
	*	@pre	music type is set.
	*	@post	music type is on screen.
	*/
	void DisplayTypeOnScreen()
	{
		cout << "\tType   : " << m_Type << endl;
	}

	/**
	*	@brief	Display music name on screen.
	*	@pre	music name is set.
	*	@post	music name is on screen.
	*/
	void DisplayNameOnScreen()
	{
		cout << "\tName : " << m_Name << endl;
	}

	/**
	*	@brief	Display music composer on screen.
	*	@pre	music composer is set.
	*	@post	music composer is on screen.
	*/
	void DisplayComposerOnScreen()
	{
		cout << "\tComposer : " << m_Composer << endl;
	}

	/**
	*	@brief	Display music singer on screen.
	*	@pre	music singer is set.
	*	@post	music singer is on screen.
	*/
	void DisplaySingerOnScreen()
	{
		cout << "\tSinger : " << m_Singer << endl;
	}

	/**
	*	@brief	Display music genre on screen.
	*	@pre	music genre is set.
	*	@post	music genre is on screen.
	*/
	void DisplayGenreOnScreen()
	{
		cout << "\tGenre : " << m_Genre << endl;
	}

	/**
	*	@brief	Display music id on screen.
	*	@pre	music id is set.
	*	@post	music id is on screen.
	*/
	void DisplayIdOnScreen()
	{
		cout << "\tId : " << m_Id << endl;
	}

	/**
	*	@brief	Display a music record on screen.
	*	@pre	music record is set.
	*	@post	music record is on screen.
	*/
	void DisplayRecordOnScreen()
	{
		DisplayTypeOnScreen();
		DisplayNameOnScreen();
		DisplayComposerOnScreen();
		DisplaySingerOnScreen();
		DisplayGenreOnScreen();
		DisplayIdOnScreen();
	}

	/**
	*	@brief	Set music type from keyboard.
	*	@pre	none.
	*	@post	music type is set.
	*/
	void SetTypeFromKB();

	/**
	*	@brief	Set music name from keyboard.
	*	@pre	none.
	*	@post	music name is set.
	*/
	void SetNameFromKB();

	/**
	*	@brief	Set music composer from keyboard.
	*	@pre	none.
	*	@post	music composer is set.
	*/
	void SetComposerFromKB();

	/**
	*	@brief	Set music singer from keyboard.
	*	@pre	none.
	*	@post	music singer is set.
	*/
	void SetSingerFromKB();

	/**
	*	@brief	Set music genre from keyboard.
	*	@pre	none.
	*	@post	music genre is set.
	*/
	void SetGenreFromKB();

	/**
	*	@brief	Set music id from keyboard.
	*	@pre	none.
	*	@post	music id is set.
	*/
	void SetIdFromKB();

	/**
	*	@brief	Set music record from keyboard.
	*	@pre	none.
	*	@post	music record is set.
	*/
	void SetRecordFromKB();

	/**
	*	@brief	Read a record from file.
	*	@pre	the target file is opened.
	*	@post	student record is set.
	*	@param	fin	file descriptor.
	*	@return	return 1 if this function works well, otherwise 0.
	*/
	int ReadDataFromFile(ifstream& fin);

	/**
	*	@brief	Write a record into file.
	*	@pre	the target file is opened. And the list should be initialized.
	*	@post	the target file is included the new student record.
	*	@param	fout	file descriptor.
	*	@return	return 1 if this function works well, otherwise 0.
	*/
	int WriteDataToFile(ofstream& fout);

	/**
	*	Compare two itemtypes.
	*	@brief	Compare two item types by item id.
	*	@pre	two item types should be initialized.
	*	@post	the target file is included the new item record.
	*	@param	data	target item for comparing.
	*	@return	return < is true if this.id < data.id,
	*			return > is true if this.id > data.id then,
	*			return == is true if this.id == data.id then,
	*/
	bool operator==(const MasterItem &data);
	bool operator>(const MasterItem &data);
	bool operator<(const MasterItem &data);

protected:
	int m_Type;			///< music type.
	string m_Name;		///< music name.
	string m_Composer;	///< music composer.
	string m_Singer;	///< music singer.
	int m_Genre;		///< music genre.
	string m_Id;		///< music ID..
};

#endif	// _ITEMTYPE_H
