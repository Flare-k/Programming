#include "SongItem.h"

// Set music Id from keyboard.
void SongItem::SetNameFromKB()
{
	cout << "\tName : ";
	cin >> m_Name;
	SetName(m_Name);
}

// Set music NumPlay from keyboard.
void SongItem::SetIdFromKB()
{
	cout << "\tId : ";
	cin >> m_Id;
	SetId(m_Id);
}

// Set music record from keyboard.
void SongItem::SetRecordFromKB()
{
	SetIdFromKB();
	SetNameFromKB();
}

// Compare two itemtypes.
bool SongItem::operator==(const SongItem &data)
{
	if (this->m_Id == data.m_Id)
		return true;
	return false;
}

// deep copy
void SongItem::operator=(const SongItem &data)
{
	this->m_Id = data.m_Id;
	this->m_Name = data.m_Name;
}