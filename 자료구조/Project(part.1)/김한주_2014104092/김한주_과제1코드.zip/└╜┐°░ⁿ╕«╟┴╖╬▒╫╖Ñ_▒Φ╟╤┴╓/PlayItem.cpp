#include "PlayItem.h"

int PlayItem::TIME = 0;

// Set music Id from keyboard.
void PlayItem::SetIdFromKB()
{
	cout << "\tID : ";
	cin >> m_Id;
	SetId(m_Id);
}

// Set music NumPlay from keyboard.
void PlayItem::SetNumPlayFromKB()
{
	cout << "\tNumPlay : ";
	cin >> m_NumPlay;
	SetNumPlay(m_NumPlay);
}

// Set music InTime from keyboard.
void PlayItem::SetInTimeFromKB()
{
	cout << "\tInTime : ";
	cin >> m_InTime;
	SetInTime(m_InTime);
}

// Set music record from keyboard.
void PlayItem::SetRecordFromKB()
{
	SetIdFromKB();
	SetNumPlayFromKB();
	SetInTimeFromKB();
}

// Compare two itemtypes.
bool PlayItem::operator==(const PlayItem &data)
{
	if (this->m_Id == data.m_Id)
		return true;
	return false;
}