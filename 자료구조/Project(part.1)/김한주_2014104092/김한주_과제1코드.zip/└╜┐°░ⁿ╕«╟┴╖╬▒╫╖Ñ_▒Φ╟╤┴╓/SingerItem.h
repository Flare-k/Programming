#pragma once
#include "UnsortedLinkedList.h"
#include "SongItem.h"
#include <iostream>
#include <string>
using namespace std;


/**
*	item information class.
*/
class SingerItem
{
public:
	/**
	*	default constructor.
	*/
	SingerItem()
	{
		m_Name = "";
		m_Age = -1;
		m_Gender = ' ';
		m_SongList = new UnsortedLinkedList<SongItem>;
	}

	/**
	*	destructor.
	*/
	~SingerItem() {}

	/**
	*	@brief	Get name.
	*	@pre	name is set.
	*	@post	none.
	*	@return	name
	*/
	string GetName()
	{
		return m_Name;
	}

	/**
	*	@brief	Get age.
	*	@pre	age is set.
	*	@post	none.
	*	@return	age.
	*/
	int GetAge()
	{
		return m_Age;
	}

	/**
	*	@brief	Get gender
	*	@pre	gender is set.
	*	@post	none.
	*	@return	gender.
	*/
	char GetGender()
	{
		return m_Gender;
	}

	/**
	*	@brief	Get Song List
	*	@pre	song list is set.
	*	@post	none.
	*	@return	song list.
	*/
	UnsortedLinkedList<SongItem>* GetSongList()
	{
		return m_SongList;
	}

	/**
	*	@brief	Set name.
	*	@pre	none.
	*	@post	name is set.
	*	@param	name	name.
	*/
	void SetName(string inName)
	{
		m_Name = inName;
	}

	/**
	*	@brief	Set age.
	*	@pre	none.
	*	@post	age is set.
	*	@param	age	age.
	*/
	void SetAge(int inAge)
	{
		m_Age = inAge;
	}

	/**
	*	@brief	Set gender.
	*	@pre	none.
	*	@post	gender is set.
	*	@param	gender	gender.
	*/
	void SetGender(char inGender)
	{
		m_Gender = inGender;
	}

	/**
	*	@brief	add song.
	*	@pre	none.
	*	@post	song is added.
	*	@param	item	song.
	*/
	void AddSong(SongItem item)
	{
		m_SongList->Add(item);
	}

	/**
	*	@brief	Set music record.
	*	@pre	none.
	*	@post	music record is set.
	*	@param	inname	name.
	*	@param	inage	age.
	*	@param	ingender gender
	*/
	void SetRecord(string inName, int inAge, char inGender)
	{
		SetName(inName);
		SetAge(inAge);
		SetGender(inGender);
	}

	/**
	*	@brief	Display name on screen.
	*	@pre	name is set.
	*	@post	name is on screen.
	*/
	void DisplayNameOnScreen()
	{
		cout << "\tName   : " << m_Name << endl;
	}

	/**
	*	@brief	Display age on screen.
	*	@pre	age is set.
	*	@post	age is on screen.
	*/
	void DisplayAgeOnScreen()
	{
		cout << "\tAge : " << m_Age << endl;
	}

	/**
	*	@brief	Display gender on screen.
	*	@pre	gender is set.
	*	@post	gender is on screen.
	*/
	void DisplayGenderOnScreen()
	{
		cout << "\tGender : " << m_Gender << endl;
	}

	/**
	*	@brief	Display song list on screen.
	*	@pre	song list is set.
	*	@post	song list is on screen.
	*/
	void DisplaySongListOnScreen()
	{
		int size = m_SongList->GetLength();
		SongItem item;
		m_SongList->ResetList(); // curPointer �ʱ�ȭ
		for (int i = 0; i < size; ++i)
		{
			m_SongList->GetNextItem(item);
			cout << "####################################" << endl;
			item.DisplayRecordOnScreen();
		}
	}

	/**
	*	@brief	Display a music record on screen.
	*	@pre	music record is set.
	*	@post	music record is on screen.
	*/
	void DisplayRecordOnScreen()
	{
		DisplayNameOnScreen();
		DisplayAgeOnScreen();
		DisplayGenderOnScreen();
		DisplaySongListOnScreen();
	}

	/**
	*	@brief	Set music Id from keyboard.
	*	@pre	none.
	*	@post	music Id is set.
	*/
	void SetNameFromKB();

	/**
	*	@brief	Set music NumPlay from keyboard.
	*	@pre	none.
	*	@post	music NumPlay is set.
	*/
	void SetAgeFromKB();

	/**
	*	@brief	Set music InTime from keyboard.
	*	@pre	none.
	*	@post	music InTime is set.
	*/
	void SetGenderFromKB();

	/**
	*	@brief	Set music record from keyboard.
	*	@pre	none.
	*	@post	music record is set.
	*/
	void SetRecordFromKB();

	/**
	*	Compare two itemtypes.
	*	@brief	Compare two item types by item id.
	*	@pre	two item types should be initialized.
	*	@post	the target file is included the new item record.
	*	@param	data	target item for comparing.
	*	@return	return == is true if this.id == data.id then,
	*/
	bool operator==(const SingerItem &data);
	void operator=(const SingerItem &data);
	bool operator>(const SingerItem &data);

protected:
	string m_Name;		///< name
	int m_Age;		///< age
	char m_Gender;		///< gender
	UnsortedLinkedList<SongItem>* m_SongList;	///< song list
};