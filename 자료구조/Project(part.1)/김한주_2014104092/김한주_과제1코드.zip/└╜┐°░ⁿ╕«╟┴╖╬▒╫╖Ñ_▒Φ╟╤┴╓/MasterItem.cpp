#include "MasterItem.h"

// Set music type from keyboard.
void MasterItem::SetTypeFromKB()
{
	cout << "\tType : ";
	cin >> m_Type;
}

// Set music name from keyboard.
void MasterItem::SetNameFromKB()
{
	cout << "\tName : ";
	cin >> m_Name;
}

// Set music composer from keyboard.
void MasterItem::SetComposerFromKB()
{
	cout << "\tComposer : ";
	cin >> m_Composer;
}

// Set music singer from keyboard.
void MasterItem::SetSingerFromKB()
{
	cout << "\tSinger : ";
	cin >> m_Singer;
}

// Set music genre from keyboard.
void MasterItem::SetGenreFromKB()
{
	cout << "\tGenre(0~4) : ";
	cin >> m_Genre;
}

// Set music id from keyboard.
void MasterItem::SetIdFromKB()
{
	cout << "\tID : ";
	cin >> m_Id;
}

// Set music record from keyboard.
void MasterItem::SetRecordFromKB()
{
	SetTypeFromKB();
	SetNameFromKB();
	SetComposerFromKB();
	SetSingerFromKB();
	SetGenreFromKB();
	SetIdFromKB();
}


// Read a record from file.
int MasterItem::ReadDataFromFile(ifstream& fin)
{
	fin >> m_Type;
	fin >> m_Name;
	fin >> m_Composer;
	fin >> m_Singer;
	fin >> m_Genre;
	fin >> m_Id;

	return 1;
}


// Write a record into file.
int MasterItem::WriteDataToFile(ofstream& fout)
{
	fout << endl;
	fout << m_Type << " ";
	fout << m_Name << " ";
	fout << m_Composer << " ";
	fout << m_Singer << " ";
	fout << m_Genre << " ";
	fout << m_Id;

	return 1;
}

// Compare two itemtypes.
bool MasterItem::operator==(const MasterItem &data)
{
	if(this->m_Id == data.m_Id)
		return true;
	return false;
}

// Compare two itemtypes.
bool MasterItem::operator>(const MasterItem &data)
{
	if (this->m_Id > data.m_Id)
		return true;
	return false;
}


// Compare two itemtypes.
bool MasterItem::operator<(const MasterItem &data)
{
	if (this->m_Id < data.m_Id)
		return true;
	return false;
}