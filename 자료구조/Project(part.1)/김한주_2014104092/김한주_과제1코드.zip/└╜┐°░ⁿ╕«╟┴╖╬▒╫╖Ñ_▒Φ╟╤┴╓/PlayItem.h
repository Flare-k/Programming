#pragma once

#include <iostream>
#include <string>

using namespace std;


/**
*	item information class.
*/
class PlayItem
{
public:
	/**
	*	default constructor.
	*/
	PlayItem()
	{
		m_Id = "";
		m_NumPlay = 0;
		m_InTime = TIME;
		TIME++;
	}

	/**
	*	destructor.
	*/
	~PlayItem() {}

	/**
	*	@brief	Get music Id.
	*	@pre	music Id is set.
	*	@post	none.
	*	@return	music Id
	*/
	string GetId()
	{
		return m_Id;
	}

	/**
	*	@brief	Get music NumPlay.
	*	@pre	music NumPlay is set.
	*	@post	none.
	*	@return	music NumPlay.
	*/
	int GetNumPlay()
	{
		return m_NumPlay;
	}

	/**
	*	@brief	Get music InTime
	*	@pre	music InTime is set.
	*	@post	none.
	*	@return	music InTime.
	*/
	int GetInTimer()
	{
		return m_InTime;
	}

	/**
	*	@brief	Set music Id.
	*	@pre	none.
	*	@post	music Id is set.
	*	@param	inId	music Id.
	*/
	void SetId(string inId)
	{
		m_Id = inId;
	}

	/**
	*	@brief	Set music NumPlay.
	*	@pre	none.
	*	@post	music NumPlay is set.
	*	@param	inNumPlay	music NumPlay.
	*/
	void SetNumPlay(int inNumPlay)
	{
		m_NumPlay = inNumPlay;
	}

	/**
	*	@brief	Set music InTime.
	*	@pre	none.
	*	@post	music InTime is set.
	*	@param	inInTime	music InTime.
	*/
	void SetInTime(int inInTime)
	{
		m_InTime = inInTime;
	}

	/**
	*	@brief	Set music record.
	*	@pre	none.
	*	@post	music record is set.
	*	@param	inId	music Id.
	*	@param	inNumPlay	music NumPlay.
	*	@param	inInTime music InTime
	*/
	void SetRecord(string inId, int inNumPlay, int inInTime)
	{
		SetId(inId);
		SetNumPlay(inNumPlay);
		SetInTime(inInTime);
	}

	/**
	*	@brief	Display music id on screen.
	*	@pre	music ide is set.
	*	@post	music id is on screen.
	*/
	void DisplayIdOnScreen()
	{
		cout << "\tId   : " << m_Id << endl;
	}

	/**
	*	@brief	Display music NumPlay on screen.
	*	@pre	music NumPlay is set.
	*	@post	music NumPlay is on screen.
	*/
	void DisplayNumPlayOnScreen()
	{
		cout << "\tNumPlay : " << m_NumPlay << endl;
	}

	/**
	*	@brief	Display music InTime on screen.
	*	@pre	music InTime is set.
	*	@post	music InTime is on screen.
	*/
	void DisplayInTimeOnScreen()
	{
		cout << "\tInTime : " << m_InTime << endl;
	}

	/**
	*	@brief	Display a music record on screen.
	*	@pre	music record is set.
	*	@post	music record is on screen.
	*/
	void DisplayRecordOnScreen()
	{
		DisplayIdOnScreen();
		DisplayNumPlayOnScreen();
		DisplayInTimeOnScreen();
	}

	/**
	*	@brief	Set music Id from keyboard.
	*	@pre	none.
	*	@post	music Id is set.
	*/
	void SetIdFromKB();

	/**
	*	@brief	Set music NumPlay from keyboard.
	*	@pre	none.
	*	@post	music NumPlay is set.
	*/
	void SetNumPlayFromKB();

	/**
	*	@brief	Set music InTime from keyboard.
	*	@pre	none.
	*	@post	music InTime is set.
	*/
	void SetInTimeFromKB();

	/**
	*	@brief	Set music record from keyboard.
	*	@pre	none.
	*	@post	music record is set.
	*/
	void SetRecordFromKB();

	/**
	*	Compare two itemtypes.
	*	@brief	Compare two item types by item id.
	*	@pre	two item types should be initialized.
	*	@post	the target file is included the new item record.
	*	@param	data	target item for comparing.
	*	@return	return == is true if this.id == data.id then,
	*/
	bool operator==(const PlayItem &data);

protected:
	string m_Id;		///< music ID..
	int m_NumPlay;		///< how many play
	int m_InTime;		///< insert time
	static int TIME;	///< TIME
};