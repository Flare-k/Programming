만든 이 : 컴퓨터공학과 2016104109 김성수

프로그램 설명
 - <자료구조>시간 실습 내용에 기반해서, 기본적인 음원 관리 기능을 수행할 수 있도록 구현했음
 - 프로그램은 크게 Master List, Play List로 나눌 수 있음
 - 각 Master List와 Play List는 template function을 이용해 Generic하도록 구현했음
 - Master List는 Unsorted List로, Play List는 Circular Linked List로 구현했음
 - Master List에서 곡, 가수명, 가사파일을 검색, 수정, 저장, 출력할 수 있음
 - Play List에 곡 정보를 추가하기 위해선, Master List에 곡이 반드시 저장돼있어야 함
 - Play List에서 곡, 가수명, 가사파일을 검색, 좋아요 표시, 저장, 출력할 수 있음
 - PlayList에서는 수정이 불가능하도록 구현했음

프로그램의 핵심 특징(나만의 특징)
 - Master List
  1. 가사(Lyric) 입, 출력, 수정까지 가능한 음원 관리 프로그램
  2. 가사의 '하이라이트' 부분만 출력할 수 있음(가사 파일에서 쌍따옴표 "~~~"가 들어간 부분 출력)

 - Play List
  1. PlayList에서도 '좋아요' 표시 가능
  2. Like 표시한 노래 재생 가능
