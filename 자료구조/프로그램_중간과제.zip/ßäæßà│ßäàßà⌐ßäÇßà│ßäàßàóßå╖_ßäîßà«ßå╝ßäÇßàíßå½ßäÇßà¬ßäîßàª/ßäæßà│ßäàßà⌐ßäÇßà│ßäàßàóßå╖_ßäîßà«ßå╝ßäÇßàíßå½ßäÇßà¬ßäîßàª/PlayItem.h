#pragma once
#include <iostream>
#include <fstream>
#include <string>

using namespace std;
//Play List에 들어갈 객체.
class PlayItem{
private:
    string music;       //곡명
    string primary;     //고유번호
    int numPlay;        //실행된 횟수
    int inTime;         //들어온 순서
    int like;           //좋*아요
    
public:
    PlayItem(){
        music = "";
        primary = "";
        numPlay = 0;
        inTime = 0;
        like = 0;
    }
    ~PlayItem(){}
    
    string GetMusic(){return music;}
    string GetPrimary() const{return primary;}
    int GetTime(){return inTime;}
    int GetNumPlay(){return numPlay;}
    int GetLike(){return like;}
    
    void SetMusic(string _music){music = _music;}
    void SetPrimary(string inPri){primary = inPri;}
    void SetTime(int _inTime){inTime = _inTime;}
    void SetNumPlay(int _numPlay){numPlay = _numPlay;}
    void SetLike(int _like){like = _like;}
    
    void SetRecord(string _music, string inPri, int _inTime, int _numPlay, int _like){
        SetMusic(_music);
        SetPrimary(inPri);
        SetTime(_inTime);
        SetNumPlay(_numPlay);
        SetLike(_like);
    }
    
    
    // 고유번호 / 들어온 순서 / 재생된 횟수
    void DisplayMusicOnScreen(){
        cout<<"\t Music: "<<music<<endl;
    }
    void DisplayPrimaryOnScreen(){
        cout<<"\t Primary: "<<primary<<endl;
    }
    void DisplayTimeOnScreen(){
        cout<<"\t Input Order: "<<inTime<<endl;
    }
    void DisplayNumPlayOnScreen(){
        cout<<"\t Play Times: "<<numPlay<<endl;
    }
    void DisplayLikeOnScreen(){
        cout<<"\t Like : "<<like<<endl;
    }
    void DisplayPLRecordOnScreen(){
        DisplayMusicOnScreen();
        DisplayPrimaryOnScreen();
        DisplayTimeOnScreen();
        DisplayNumPlayOnScreen();
        DisplayLikeOnScreen();
        cout<<endl;
    }
    int ReadDataFromFile(ifstream& fin);
    int WriteDataToFile(ofstream& fout);
    bool operator==(const PlayItem& data) const;
    bool operator!=(const PlayItem& data) const;
    bool operator>(const PlayItem& data) const;
    bool operator<(const PlayItem& data) const;
};


