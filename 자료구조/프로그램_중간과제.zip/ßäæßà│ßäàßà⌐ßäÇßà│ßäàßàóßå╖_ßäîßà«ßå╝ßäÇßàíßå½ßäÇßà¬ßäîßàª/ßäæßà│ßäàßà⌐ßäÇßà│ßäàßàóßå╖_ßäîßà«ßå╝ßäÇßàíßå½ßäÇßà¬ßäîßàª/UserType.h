#pragma once
#include <iostream>
#include <fstream>
#include <string>
#include <iomanip>
#include "PlayItem.h"
#define MAXSIZE 100
using namespace std;

class UserType{
private:
    string user_id;
    string user_pw;
    int item;
    
public:
    UserType(){
        user_id = "";
        user_pw = "";
        item = 0;
        //item = new PlayItem[MAXSIZE];
    }
    UserType(int _item){
        user_id = "";
        user_pw = "";
        item = 0;
        //item = new PlayItem[MAXSIZE];
    }
    ~UserType(){
       // delete[] item;
    }
    
    string GetUserID() const {return user_id;}
    string GetUserPW() const {return user_pw;}
    int GetUserRecord() {return item;}
    
    void SetUserID(string _user_id){user_id = _user_id;}
    void SetUserPW(string _user_pw){user_pw = _user_pw;}
    void SetUserRecord(int _item){item = _item;}
    
    void SetUserRecord(string _user_id, string _user_pw){
        SetUserID(_user_id);
        SetUserPW(_user_pw);
    }
    
    
    void DisplayUserIDOnScreen(){
        cout<<"\t 아이디: "<<user_id<<endl;
    }
    void DisplayUserPWOnScreen(){
        cout<<"\t 비밀번호: "<<user_pw<<endl;
    }
    
    void DisplayUserOnScreen(){
        DisplayUserIDOnScreen();
        DisplayUserPWOnScreen();
        cout<<endl;
    }
    
    void SetUserIDFromKB();
    void SetUserPWFromKB();
    void SetUserFromKB();
    
    int ReadDataFromFile(ifstream& fin);
    int WriteDataToFile(ofstream& fout);
    
    bool operator==(const UserType& data) const;
    bool operator!=(const UserType& data) const;
    bool operator>(const UserType& data) const;
    bool operator<(const UserType& data) const;
};


