//
//  UserType.cpp
//  프로그램_중간과제
//
//  Created by Flare_k on 05/11/2019.
//  Copyright © 2019 Flare_k. All rights reserved.
//

#include "UserType.h"


void UserType::SetUserIDFromKB(){ //키보드로 '회원 아이디' 입력
    cout<<"\t 아이디: ";
    cin>>user_id;
}
void UserType::SetUserPWFromKB(){ //키보드로 '회원 비밀번호' 입력
    cout<<"\t 비밀번호: ";
    cin>>user_pw;
}
void UserType::SetUserFromKB(){ //키보드로 '전체 회원정보' 입력
    SetUserIDFromKB();
    SetUserPWFromKB();
}

int UserType::ReadDataFromFile(ifstream& fin){      //객체에 파일의 내용을 읽어온다.
    fin>>user_id;
    fin>>user_pw;
    
    return 1;
}

int UserType::WriteDataToFile(ofstream& fout){      //객체의 내용을 파일에 저장해준다.
    fout<<endl;
    fout<<user_id<<" ";
    fout<<user_pw;
    return 1;
}
// '=='를 가능하게 하는 연산자 오버로딩
bool UserType::operator==(const UserType& data) const {
    if(this->user_id == data.user_id && this->user_pw == data.user_pw)
        return true;
    else
        return false;
}
// '!='를 가능하게 하는 연산자 오버로딩
bool UserType::operator!=(const UserType& data) const {
    if(this->user_id != data.user_id && this->user_pw != data.user_pw)
        return true;
    else
        return false;
}
// 비교연산자 오버로딩 ' > '
bool UserType::operator>(const UserType& data) const {
    if(this->user_id > data.user_id && this->user_pw > data.user_pw)
        return true;
    else
        return false;
}
// 비교연산자 오버로딩 ' < '
bool UserType::operator<(const UserType& data) const {
    if(this->user_id < data.user_id && this->user_pw < data.user_pw)
        return true;
    else
        return false;
}
