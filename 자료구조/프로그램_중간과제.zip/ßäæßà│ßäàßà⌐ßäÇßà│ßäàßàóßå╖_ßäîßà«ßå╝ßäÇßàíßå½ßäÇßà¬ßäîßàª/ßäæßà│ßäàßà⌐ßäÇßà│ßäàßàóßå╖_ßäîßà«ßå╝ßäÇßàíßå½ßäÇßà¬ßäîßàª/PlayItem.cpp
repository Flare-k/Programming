#include "PlayItem.h"
int PlayItem::ReadDataFromFile(ifstream& fin){
    fin>>music;
    fin>>primary;
    fin>>numPlay;
    fin>>inTime;
    fin>>like;
    return 1;
}
int PlayItem::WriteDataToFile(ofstream& fout){
    fout<<endl;
    fout<<music<<" ";
    fout<<primary<<" ";
    fout<<numPlay<<" ";
    fout<<inTime<<" ";
    fout<<like;
    return 1;
}

// '=='를 가능하게 하는 연산자 오버로딩
bool PlayItem::operator==(const PlayItem& data) const {
    if(this->primary == data.GetPrimary())
        return true;
    else
        return false;
}
// '!='를 가능하게 하는 연산자 오버로딩
bool PlayItem::operator!=(const PlayItem& data) const {
    if(this->primary != data.GetPrimary())
        return true;
    else
        return false;
}


// 비교연산자 오버로딩 ' > '
bool PlayItem::operator>(const PlayItem& data) const {
    if(this->primary > data.GetPrimary())
        return true;
    else
        return false;
}

// 비교연산자 오버로딩 ' < '
bool PlayItem::operator<(const PlayItem& data) const {
    if(this->primary < data.GetPrimary())
        return true;
    else
        return false;
}
